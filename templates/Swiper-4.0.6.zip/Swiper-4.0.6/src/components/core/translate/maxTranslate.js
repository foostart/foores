export default function () {
  return (-this.snapGrid[this.snapGrid.length - 1]);
}
